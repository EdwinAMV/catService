<!-- resources/views/cat/index.blade.php -->

<h1>Lista de imágenes de gatos</h1>

<?php $__currentLoopData = $catImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <strong>ID:</strong> <?php echo e($catImage->_id); ?><br>
        <strong>Mimetype:</strong> <?php echo e($catImage->mimetype); ?><br>
        <strong>Tamaño:</strong> <?php echo e($catImage->size); ?><br>
        <strong>Etiquetas:</strong>

        <?php if($catImage->tags): ?>
            <?php $__currentLoopData = json_decode($catImage->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge badge-primary"><?php echo e($tag); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <span>Sin etiquetas</span>
        <?php endif; ?>
    </div>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\danal\OneDrive\Documentos\DAW2\M7 - Desarrollo web en entorno servidor\CatService\cataas\resources\views/cat/index.blade.php ENDPATH**/ ?>